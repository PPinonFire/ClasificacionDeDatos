#include <iostream>
#include<math.h>
using namespace std;

void calcular_regresion_cuadratica(float x[], float y[], float  n, float &a, float &b, float  &c) {
    float sum_x = 0.0, sum_y = 0.0, sum_x2 = 0.0, sum_x3 = 0.0, sum_x4 = 0.0, sum_xy = 0.0, sum_x2y = 0.0;

    for (int i = 0; i < n; i++) {
        sum_x += x[i];
        sum_y += y[i];
        sum_x2 += x[i] * x[i];
        sum_x3 += x[i] * x[i] * x[i];
        sum_x4 += x[i] * x[i] * x[i] * x[i];
        sum_xy += x[i] * y[i];
        sum_x2y += x[i] * x[i] * y[i];
    }

    /*cout <<"sum_x "<<sum_x<<endl;
    cout <<"sum_y "<<sum_y<<endl;
    cout <<"sum_x2 "<<sum_x2<<endl;
    cout <<"sum_3 "<<sum_x3<<endl;
    cout <<"sum_x4 "<<sum_x4<<endl;
    cout <<"sum_xy "<<sum_xy<<endl;
    cout <<"sum_x2y "<<sum_x2y<<endl;*/


     float denom = ((sum_x2*sum_x2*sum_x2)+(sum_x*sum_x*sum_x4)+(n*sum_x3*sum_x3))-((n*sum_x2*sum_x4)+(sum_x*sum_x3*sum_x2)+(sum_x2*sum_x*sum_x3));

    a= (((sum_y*sum_x2*sum_x2)+(sum_x*sum_x*sum_x2y)+(n*sum_xy*sum_x3))-((n*sum_x2*sum_x2y)+(sum_x*sum_x3*sum_y)+(sum_x2*sum_x*sum_xy)))/denom;
    b= ((sum_x2 * sum_xy * sum_x2) + (sum_y * sum_x * sum_x4) + (n * sum_x3 * sum_x2y) - (n * sum_xy * sum_x4) - (sum_x2 * sum_x * sum_x2y) - (sum_y * sum_x3 * sum_x2))/denom;
    c = (((sum_x2*sum_x2*sum_x2y)+(sum_x*sum_xy*sum_x4)+(sum_y*sum_x3*sum_x3))-((sum_y*sum_x2*sum_x4)+(sum_xy*sum_x3*sum_x2)+(sum_x2y*sum_x*sum_x3)))/denom;
    /*cout <<"denom "<<denom<<endl;
    cout <<"a "<<a<<endl;
    cout <<"b "<<b<<endl;
    cout <<"c "<<c<<endl;*/

}

int main() {
    float x[] = {-3,-2,-1,0,1,2,3};
    float  y[] = {7.5,3,0.5,1,3,6,14};
    int n = 7;
    float a, b, c,input,result,SSE=0,SST=0,hat_y=0;

    calcular_regresion_cuadratica(x, y, n, a, b, c);

    cout << "La ecuacion de la regresion cuadratica es: Y = " << a << "X^2 + " << b << "X + " << c << endl;

    for (int i=0; i < n;i++)
    {
        hat_y += y[i];
    }
    hat_y /=n;

    for (int i=0; i < n;i++)
    {
        SSE += pow(y[i]-a*pow(x[i],2)-b*x[i]-c,2);
        SST += pow(y[i]-hat_y,2);
    }

    result = 1-(SSE/SST);
    cout << "R^2 de los datos es: "<<result<<endl;

    cout << "Ingrese valor de X: ";
    cin >> input;
    result = a*(input*input)+b*(input)+c;
    cout << "El mejor valor de Y encontrado para el valor de X propuesto es: "<<result<<endl;

    return 0;
}
