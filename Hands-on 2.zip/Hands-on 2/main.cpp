#include <iostream>
#include "Calculo.h"
using namespace std;

int main()
{
    Calculo calculo;
    float y[9]={5,10,15,20,25,30,35,40,45};
    float x[9]={1,2,3,4,5,6,7,8,9};
    float a;
    cout << "El resultado de B0 es:" << calculo.B0(x,y)<<endl;
    cout << "El resultado de B1 es:" << calculo.B1(x,y)<<endl;
    cout << endl<< "Ingrese el valor X para calcular su Y:" ;
    cin >> a;
    a = calculo.B0(x,y) + calculo.B1(x,y)*a;
    cout << "El resultado es: "<<a;
    return 0;
}

